import * as React from 'react';
import { Text, Button, View } from 'react-native';

export default function Xbutton(props: IXbutton) {
  function tecla(key) {
    props.onPress(key);
  }

  const size = (props.size ?? 30) - 1;

  return (
    <View>
      <Text
        style={{
          margin: 1,
          borderRadius: 3,
          borderColor: 'purple',
          backgroundColor: 'purple',
          width: size,
          height: size,
          fontSize: (size * 2) /3,
          textAlign: 'center'
        }}
        onPress={() => tecla(2)}>
        {props.title}
      </Text>
    </View>
  );
}

interface IXbutton {
  title: string;
  onPress: (k) => void;
  size: number;
}
