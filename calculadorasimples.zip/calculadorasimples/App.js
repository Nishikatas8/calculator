import * as React from 'react';
import {Text, View, StyleSheet, Button} from 'react-native';
import Teclado from './teclado'

export default function App() {

  const [display,  displaySet] = React.useState(0)
  const [memoria,  memoriaSet] = React.useState(0)
  const [operacao,  operacaoSet] = React.useState("")

  function tecla(valor) {
    if(valor =="C") {
        memoriaSet(0)
        operacaoSet(display)
        displaySet(0)
    } else if(valor =="=") {
      if(operacao=="-"){
       displaySet(memoria - display) 
      } else if(operacao=="+") {
        displaySet(memoria + display)
      } else if(operacao=="X") {
        displaySet(memoria * display)
      } else if(operacao=="/") {
        displaySet(memoria / display)
      }

    } else if(valor =="+") {
        memoriaSet(display)
        operacaoSet(valor)
        displaySet(0)
    } else if(valor =="-") {
        memoriaSet(display)
        operacaoSet(valor)
        displaySet(0)
    } else if(valor =="X") {
        memoriaSet(display)
        operacaoSet(valor)
        displaySet(0)
    } else if(valor =="/") {
        memoriaSet(display)
        operacaoSet(valor)
        displaySet(0)
    } else {
       displaySet(display * 10 + valor)
    }
 }
  
  const size = 120;

  return (
    <View
      style={{
        width: size,
        borderColor: 'black',
        borderWidth: 2,
        padding: 5,
        borderRadius: 10,
        margin: 50,
      }}>
      <Text>
        {memoria} {operacao}
        </Text>
        <Text
          style={{ fontSize: 30, backgroundColor: '#a0a0a0', textAlign: 'right'}}>
          {display}
        </Text>
    <Teclado onKey={tecla} size={size-14}/>
  </View>
  );
}